def lambda_handler():
    pass