import pg8000.native as pg
from pg8000.exceptions import InterfaceError
import boto3
import logging

test_bucket = 'sqhells-transform-data'
logger = logging.getLogger('SQHellsLogger')
logger.setLevel(logging.INFO)

def connect():
    """ small utility to test the connection to warehouse database"""
    try:
        hostname='nc-data-eng-project-dw-prod.chpsczt8h1nu.eu-west-2.rds.amazonaws.com'
        parole='5v8FmZSgQEdCxtN'
        conn = pg.Connection(user='project_team_1',host=hostname,password=parole,database='postgres')
        result =conn.run('SELECT * FROM dim_currency')
        titles = [ meta_data['name'] for meta_data in conn.columns]
        print(f'titles: {titles}')
    except Exception as ex:
        print(f'error_msg: {ex}')

    pass 

def list_bucket_objects(bucket_name):
    """ the function reads the name of files(keys) in the S3 bukets
        using boto3 Client
        Args: bucket name
        Returns: the client and the list of filenames (s3 keys)
    """
    try:
        logger.info(f'listing bucket{bucket_name}')
        client = boto3.client('s3')
        bucket_contents = client.list_objects_v2(Bucket=bucket_name)
        objects = []
        if 'Contents' in bucket_contents:
            objects = [obj['Key'] for obj in bucket_contents['Contents']]
    except Exception as e:
        logger.error(e)
    return client, objects

def get_bucket_objects(bucket_name):
    try:
        logger.info(f'getting bucket{bucket_name}')
        s3 = boto3.resource('s3')
        bucket = s3.Bucket(bucket_name)
        objects = [obj.key for obj in bucket.objects.all()]
    except Exception as e:
        logger.error(e)
    return objects


def get_data_from_file(client, bucket, object_key):
    """Reads the text from specified file in S3, used for AWS lambda testing."""
    logger.info(f'object key is {object_key}')
    data = client.get_object(Bucket=bucket, Key=object_key)
    contents = data['Body'].read()
    return contents.decode('utf-8')

print(list_bucket_objects(test_bucket))
print(get_bucket_objects(test_bucket))

#connect()